/** VERSION: 0.0.0 **/
/* eslint-disable import-x/extensions */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/member-ordering */
/* eslint-disable line-comment-position */
/* eslint-disable @typescript-eslint/unified-signatures */
/* eslint-disable no-var */
/* eslint-disable import-x/namespace */
// eslint-disable-next-line @typescript-eslint/triple-slash-reference, spaced-comment
/// <reference lib="DOM" />
import type {UnorderedListProps$1} from './components-shared.d.ts';

/**
 * Used when an element does not have children.
 */
export interface BaseElementProps<TClass = HTMLElement> {
    key?: preact.Key;
    ref?: preact.Ref<TClass>;
    slot?: Lowercase<string>;
}
/**
 * Used when an element has children.
 */
export interface BaseElementPropsWithChildren<TClass = HTMLElement> extends BaseElementProps<TClass> {
    children?: preact.ComponentChildren;
}

declare const tagName = "s-unordered-list";
/** @publicDocs */
export interface UnorderedListElementProps extends UnorderedListProps$1 {
}
export interface UnorderedListElement extends UnorderedListElementProps, Omit<HTMLElement, 'id'> {
}
export interface UnorderedListProps extends UnorderedListElementProps {
}
declare global {
    interface HTMLElementTagNameMap {
        [tagName]: UnorderedListElement;
    }
}
declare module 'preact' {
    namespace createElement.JSX {
        interface IntrinsicElements {
            [tagName]: UnorderedListProps & BaseElementPropsWithChildren<UnorderedListElement>;
        }
    }
}

export type { UnorderedListElement, UnorderedListElementProps, UnorderedListProps };
