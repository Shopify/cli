export declare const SFAPI_VERSION = "2026-04";
