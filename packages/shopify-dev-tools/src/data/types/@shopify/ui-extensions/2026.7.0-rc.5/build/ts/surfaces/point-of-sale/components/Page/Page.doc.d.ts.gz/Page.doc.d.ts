import { ReferenceEntityTemplateSchema } from '@shopify/generate-docs';
declare const data: ReferenceEntityTemplateSchema;
export default data;
//# sourceMappingURL=Page.doc.d.ts.map